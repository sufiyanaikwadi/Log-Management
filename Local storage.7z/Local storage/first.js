// first.js
var colorCodes = {

  back  : "#fff",
  front : "#888",
  side  : "#369"

};