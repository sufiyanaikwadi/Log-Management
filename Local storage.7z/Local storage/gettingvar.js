function getvar()
{
 localStorage.setItem("variableName", "variableContent");
}