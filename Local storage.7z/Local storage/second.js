// second.js
function second()
{
window.open(alert (colorCodes.back)); // alerts `#fff`
}